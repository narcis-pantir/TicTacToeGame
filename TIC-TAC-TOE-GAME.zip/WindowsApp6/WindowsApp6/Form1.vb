﻿Public Class Form1
    Dim Turn As Byte
    Dim X1 As Byte
    Dim O As Byte
    Dim Both As Byte


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) _
    Handles Button1.Click, Button2.Click, Button3.Click, Button4.Click, Button5.Click,
            Button6.Click, Button7.Click, Button8.Click, Button9.Click
        sender.Text = If(Turn Mod 2 = 0, "X", "0")
        sender.Enabled = False
        Turn += 1
        wincheck()
        bothwin()
    End Sub

    Private Function winningconfiguration(e1 As Button, e2 As Button, e3 As Button) As Boolean

        winningconfiguration = CBool(e1.Text = e2.Text And e2.Text = e3.Text) AndAlso (e1.Enabled = False AndAlso e2.Enabled = False AndAlso e3.Enabled = False)
        If winningconfiguration = True Then MessageBox.Show(e1.Text & "   WIN THE GAME")

        If winningconfiguration = True And e1.Text = "X" Then
            X1 = X1 + 1
            TextBox1.Text = X1
        End If

        If winningconfiguration = True And e1.Text = "0" Then
            O = O + 1
            TextBox2.Text = O
        End If

    End Function

    Private Sub wincheck()

        If winningconfiguration(Button1, Button2, Button3) OrElse
                winningconfiguration(Button4, Button5, Button6) OrElse
                winningconfiguration(Button7, Button8, Button9) OrElse
                winningconfiguration(Button1, Button5, Button9) OrElse
                winningconfiguration(Button3, Button5, Button7) OrElse
                winningconfiguration(Button1, Button4, Button7) OrElse
                winningconfiguration(Button2, Button5, Button8) OrElse
                winningconfiguration(Button3, Button6, Button9) Then
            newgame()
        End If

    End Sub

    Private Sub newgame()



        Button1.Text = ""
        Button1.Enabled = True
        Button2.Text = ""
        Button2.Enabled = True
        Button3.Text = ""
        Button3.Enabled = True
        Button4.Text = ""
        Button4.Enabled = True
        Button5.Text = ""
        Button5.Enabled = True
        Button6.Text = ""
        Button6.Enabled = True
        Button7.Text = ""
        Button7.Enabled = True
        Button8.Text = ""
        Button8.Enabled = True
        Button9.Text = ""
        Button9.Enabled = True
        Turn = 0



    End Sub

    Private Sub bothwin()
        If Turn = 9 Then
            MessageBox.Show("DRAW MATE!")
            newgame()
            Both = Both + 1
            TextBox3.Text = Both
        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        newgame()
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Controls.Clear()

        InitializeComponent()

        X1 = 0
        O = 0
        Turn = 0
        Both = 0

    End Sub
End Class